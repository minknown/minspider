<?php
//这是一个文件接口，用于转发自第二个wp论坛，必须防止于新论坛的wp根目录下边，同时设置周期性运行，一次发布一篇。采用PDO
//确保非本地数据库主机可被远程访问，如果无法链接请加入白名单或者设置nignx代理转发.
//新增了catetran方法，用于改善将分类进行转化唯一标识符，之前用md5方式比较长。
//手动设置文章内容替换模块，wp必须安装Yoast SEO、share\Related Posts插件。
//做好nr替换模块，正文内容的修改，word_tags.php里面的nu数组定义扩写内容的替换，为原创等，For 置（tdlxxs.com）

//基础配

    header("Content-type: text/html; charset=utf-8"); 
    session_start();
    error_reporting(0);
    date_default_timezone_set('PRC');
    $dn=time();
    
    $user="root";//WP管理员用户名
    $password="058Y DcRd Ty30 bSHZ 74Mb KvnO";//WP密钥,在用户管理中新建
    $writemore="https://xxxx.xyz/taolu/wordtag.php?writemore=";//为空不使用扩写
    
    $dby['ip']="localhost";//wp源主机
    $dby['dbname']="rfjfttey_talu";
    $dby['username']="rfjfttey_sb";
    $dby['password']="wwxxxxxx";
    $dby['tablename']="wp_posts";
    
    $dbn['ip']="localhost";//wp新主机
    $dbn['dbname']="rfjfttey_taovid";
    $dbn['username']="rfjfttey_sb";
    $dbn['password']="xxxxxxx!";
    $dbn['tablename']="wp_posts";   
    
    $dbv['ip']="localhost";//资源库主机
    $dbv['dbname']="rfjfttey_sub";
    $dbv['username']="rfjfttey_sub";
    $dbv['password']="xxxx";
    $dbv['tablename']="neo_toxlu";

//外部接口
if($_GET['fid']!=""){
    echo "<script>location.href='https://swxxxxxx.com/wpport.php?fid=".$_GET['fid']."';</script>";
    exit();
}
//第一步:连接数据库
try{$cony = new PDO("mysql:host=". $dby['ip'].";dbname=".$dby['dbname'],$dby['username'],$dby['password']);$cony->query("SET NAMES UTF8");}catch(PDOException $e) {
    echo "y库连接失败,可能是PDO不支持或SQL信息不对:" . $e->getMessage();exit();
}
try{$conn = new PDO("mysql:host=". $dbn['ip'].";dbname=".$dbn['dbname'],$dbn['username'],$dbn['password']);$conn->query("SET NAMES UTF8");}catch(PDOException $e) {
    echo "n库连接失败,可能是PDO不支持或SQL信息不对:" . $e->getMessage();exit();
}
try{$conv = new PDO("mysql:host=". $dbv['ip'].";dbname=".$dbv['dbname'],$dbv['username'],$dbv['password']);$conv->query("SET NAMES UTF8");}catch(PDOException $e) {
    echo "v库连接失败,可能是PDO不支持或SQL信息不对:" . $e->getMessage();exit();
}


//获取y的文章数组
 $qq = "SELECT id,post_name FROM ".$dby['tablename']." where post_type='post' order by RAND()";
 $res=$cony->query($qq); 
 while($row = $res->fetch()) {
    $vidone[]=$row['post_name'];
  }

//获取n的文章数组
 $qq = "SELECT id,post_name FROM ". $dbn['tablename']." where post_type='post' order by RAND()";
 $res=$conn->query($qq); 
 while($row = $res->fetch()) {
    $vidtwo[]=$row['post_name'];
  }
  if($_GET['ts']!=""){echo "WP_POSTS条目数量信息:n".count($vidtwo)." & y".count($vidone)."<br>";}

 
//获取随机的一个未发表的文章vid(示例值sy780).
 $cha=array_diff($vidone,$vidtwo);
 shuffle($cha);
 shuffle($cha);
 if(count($cha)>0){
     $vid=$cha[0];
 }else{
     die("[NOONE]全部发表至本站成功,暂无新的文章可发布。");
 }

//查询该vid的具体信息(v视频全信息，vpost文章信息（post_title,post_content）)
 $qq = "SELECT * FROM ". $dbv['tablename']." where vid='".$vid."' limit 1";
 $v=$conv->query($qq)->fetch(); 
 $qq = "SELECT * FROM ".$dby['tablename']." where post_name='".$vid."' and post_type='post' limit 1";
 $vpost=$cony->query($qq)->fetch();
 
//关闭数据库
$cony=null;
$conn=null;
$conv=null;

//测试模式
if($_GET['ts']!=""){
    echo "仅读取条目:<br>";
    print_r($v);
    echo "<br>------<br>";
    print_r("vpost.title=".$vpost['post_title']);
    exit();
}else{
    echo "读取并发布条目:<br>";
    print_r($v);
    echo "<br>------<br>";
    print_r("vpost.title=".$vpost['post_title']);
    echo "<br>------<br>";
}

//下一个php段主要处理发布文章的问题。
?>

<?php



//WP接口初始化
error_reporting(0);
require( dirname(__FILE__) . '/wp-load.php' );
$headers = array (
    'Authorization' => 'Basic ' . base64_encode( $user . ':' .$password ),
);


//----------FUNCTION方法------------------------

//[分类]分类名转化为唯一标识符
function catetran($cname){
    
    $all="";
    if (extension_loaded('mbstring')) {
        $len = mb_strlen($cname, 'utf-8'); // 获取字符串长度，需使用utf-8编码
        for ($i = 0; $i < $len; $i++) {
            $char = mb_substr($cname, $i, 1, 'utf-8'); // 获取单个字符
            $all=$all.ord($char);
        }
        //缩短算法
        $th=array("11"=>"9","22"=>"8","33"=>"7","44"=>"6","1"=>"a","2"=>"b","3"=>"c","4"=>"d","5"=>"e","6"=>"f","7"=>"g","8"=>"h","9"=>"j","0"=>"z");
        foreach($th as $key=>$value){
            $all=str_replace($key,$value,$all);
        }
        //增加唯一性
        $all=$all.substr(md5($cname),-4).strlen($cname);
        
    }else{
        $all="C".md5($cname);
    }

    return $all;
}

//[分类]别名获取分类ID，当分类不存在返回空。
function getcateid($theslug){
    global $headers;
    $url = rest_url( 'wp/v2/categories/' );
    $theresponse = wp_remote_post( $url, array (
    'method'  => 'GET',
    'headers' => $headers,
     'body'=>array('slug'=>$theslug)
    ) );
    $theres=json_decode($theresponse['body'],true);
    return $theres[0]['id'];
}

//[分类]创建分类(重复会创建)
function putcate($thename){
    global $headers;
    $url = rest_url( 'wp/v2/categories/' );
    $theresponse = wp_remote_post( $url, array (
    'method'  => 'POST',
    'headers' => $headers,
    'body' => array(
        'name' => $thename,
        'description' =>$thename,
        'slug'=> catetran($thename),
        'parent'=>'0'
    )));
    $res=json_decode($theresponse['body'],true);
    return $res['id'];
}


//[标签]别名获取标签ID，不存在返回空。
function gettagid($theslug){
    global $headers;
    $url = rest_url( 'wp/v2/tags/' );
    $theresponse = wp_remote_post( $url, array (
    'method'  => 'GET',
    'headers' => $headers,
    'body'=>array('slug'=>$theslug)
    ) );
    $theres=json_decode($theresponse['body'],true);
    return $theres[0]['id'];
 
}

//[标签]创建标签(重复会创建)
function puttag($thename){
    global $headers;
    $url = rest_url( 'wp/v2/tags/' );
    $theresponse = wp_remote_post( $url, array (
    'method'  => 'POST',
    'headers' => $headers,
    'body' => array(
        'name' => $thename,
        'description' =>$thename,
        'slug'=> "T".md5($thename)
    )));
    $res=json_decode($theresponse['body'],true);
    return $res['id'];
}

//[标签]别名获取文章ID，不存在返回空。
function getpostid($theslug){
    global $headers;
    $url = rest_url( 'wp/v2/posts/' );
    $theresponse = wp_remote_post( $url, array (
    'method'  => 'GET',
    'headers' => $headers,
    'body'=>array('slug'=>$theslug)
    ) );
    $theres=json_decode($theresponse['body'],true);
    return $theres[0]['id'];
 
}

//-----------------------------------------------------


//正式发布文章[需传入post.catename,title,nr]

    $_POST['nr']=$vpost['post_content'];
    $_POST['nr']=str_replace("FGF","'",$_POST['nr']);
    $_POST['title']=$vpost['post_title'];
    $_POST['catename']=$v['uper'];
    $_POST['slug']=$v['vid'];
    
    //nr替换模块
    if($writemore!=""){
        $more=file_get_contents($writemore.urlencode($_POST['title']));
        echo "More:".$more."<br>";
    }
    if($more!=""){$more="<br>更多相关:".$more;}
    $_POST['nr']=str_replace("AAAA","new",$_POST['nr']);
    $_POST['nr']=str_replace("BBBB","new",$_POST['nr']);
    $_POST['nr']=str_replace("完整版视频在线播放","视频完整版入口",$_POST['nr']);
    $_POST['nr']=str_replace("点击此处进入</a>","点击此处进入</a>".$more,$_POST['nr']);
     $_POST['nr']=str_replace("https://xxxxx.com/wpport.php","https://xxxxxxxx.com/sendother.php",$_POST['nr']);
    
    //带RF不做JAVA客户端提示。
    if(getpostid($_POST['slug'])>0){die("[NT][RR]发布失败,别名SLUG已经重复(发布过)");}
    $catename=$_POST['catename'];
    $cateid=getcateid(catetran($catename));

    if($cateid==""){
        echo "CreatNewCate:".$catename."(slug=".catetran($catename).")<br>";
        $cateid=putcate($catename);
    }
    if($cateid<=0){die("发布失败,分类获取和生成均失败(必须有分类才能发布)");}
    $urlwant="posts";
    $data = array(
    'status'=>'publish',
    'title' => $_POST['title'],
    'content' => $_POST['nr'],
    'categories'=>$cateid,//tags
    'slug'=>$_POST['slug']
    );



//正式提交
$url = rest_url( 'wp/v2/'.$urlwant.'/' );
$response = wp_remote_post( $url, array (
    'method'  => 'POST',
    'headers' => $headers,
    'body'    =>  $data
) );
$res=json_decode($response['body'],true);
if($res['data']['status']==""){
    echo "OK";
}else{
    echo $response['body'];
}


