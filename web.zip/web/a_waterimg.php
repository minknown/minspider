<?php
//每分钟运行1次即可。一个月后关闭判断是否无结果了再决定关闭即可。
//扫描一个目录下，随机抽取一个子目录，对该子目录下所有图片进行水印化。
//注意处理后得图片会比原来大30%，介意的话自行进行压缩参数调优。
$sy="minknown.com";
$dir="./previewforsy/";
$files=scandir($dir);
$re="";
foreach($files as $temp){
    if($temp!="." and $temp!=".." and is_dir($dir.$temp)){
          if(!file_exists($dir.$temp."/wm.tx")){
              $re=$dir.$temp."/";
              break;
          } 
    }
}
if($re==""){
    die("没有需要处理的图片目录。");
}else{
    file_put_contents($re."wm.tx","yes");
}

$jc=0;
$files=scandir($re);
foreach($files as $temp){
    if($temp!="." and $temp!=".." and substr($temp,-4)==".jpg"){
        //增加水印并保存
        $jc++;
        $obj = new Image_class($re.$temp);
        $obj->fontMark(100,10+rand(1,148),10+rand(1,148),array(255,204,0,10),$sy);
        $obj->save();
    }
}
echo "DealImage:".$re."*.jpg->dealnum:".$jc."->Finish.";
exit();

  
//图片类  
class Image_class {
  private $image;
  private $info;
  private $fname;

  /**
   * @param $src:图片路径
   * 加载图片到内存中
   */
  function __construct($src){
    $info = getimagesize($src);
    $type = image_type_to_extension($info[2],false);
    $this -> info =$info;
    $this->info['type'] = $type;
    $fun = "imagecreatefrom" .$type;
    $this -> image = $fun($src);
    $this->fname=$src;
  }

  /**
   * @param $fontsize: 字体大小
   * @param $x: 字体在图片中的x位置
   * @param $y: 字体在图片中的y位置
   * @param $color: 字体的颜色是一个包含rgba的数组
   * @param $text: 想要添加的内容
   * 操作内存中的图片,给图片添加文字水印
   */
  public function fontMark($fontsize,$x,$y,$color,$text){
    $col = imagecolorallocatealpha($this->image,$color[0],$color[1],$color[2],$color[3]);
    imagestring($this->image,$fontsize,$x,$y,$text,$col);
  }
  
  /**
   * 输出图片到浏览器中
   */
  public function save(){
    
    imagejpeg($this->image, $this->fname,100);//这里的第三个参数50可以理解为保存的百分比，范围是1-100
    //header('content-type:' . $this -> info['mime']);
    //$fun='image' . $this->info['type'];
    //$fun($this->image);
    
  }

  /**
   * 销毁图片
   */
  function __destruct(){
    imagedestroy($this->image);
  }
}
