package com.mayizt;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import net.bytebuddy.implementation.bytecode.Throw;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.codec.net.URLCodec;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 用户：Administrator
 * 描述：${desc}
 */
public class Main {
    public static String cache="";//非config文件配置项,为缓存目录，启动时带入
    public static Boolean neiadd=false;//非config文件配置项,为true时内置dealer会自动新增内容。搜postres解除注释可开启结果显示
    public static String bcdom="c";//非config文件配置项,wp文章nr叠加进入链接和图片专用URL前缀。

    public static String ser="";
    public static String output="";

    public static String urlp="";
    public static String urlv="";
    public static String logintext="";
    public static Integer timep=0;
    public static Integer timev=0;
    public static Integer ps=0;
    public static Integer pn=0;
    public static Integer pl=0;

    public static String ini="";
    public static String danvid="";

    //正则前后类
    public static String vstart="";
    public static String vend="";
    public static String vvstart="";
    public static String vvend="";
    public static String wtoken="";
    public static String taskname="";
    public static String pm="";
    public static String dealer="";
    public static String dealermore="";
    public static String iei="";


    public static void main(String[] args) throws InterruptedException, IOException {

        //启动配置初始化






        cache="E:/res";
        if(args.length!=1 && cache.isEmpty()){
            System.out.println("[Pro]请通过启动参数指定缓存目录。");
            System.exit(88);
        }else{
            if(cache.isEmpty()){
            cache=Utils.dr(args[0]);
            }
        }
        ini=cache+"/config.ini";
        System.out.println("Program by https://github.com/minknown as V1.0,Config in "+ini);
        if(FileUtils.readFileToString(new File(ini)).contains("\"")){
            System.out.println("[Pro]配置文件存在引号，请检查配置项。");
            System.exit(112);
        }
        try{
        ser=Utils.getIni(ini,"ser","");
        ps=Integer.valueOf(Utils.getIni(ini,"ps","0"));
        pn=Integer.valueOf(Utils.getIni(ini,"pn","0"));
        pl=Integer.valueOf(Utils.getIni(ini,"pl","0"));
        danvid=Utils.getIni(ini,"danvid","");
        urlp=Utils.getIni(ini,"urlp","");
        urlv=Utils.getIni(ini,"urlv","");
        logintext=Utils.getIni(ini,"logintext","#logintext#");
        timev=Integer.valueOf(Utils.getIni(ini,"timev","2000"));
        timep=Integer.valueOf(Utils.getIni(ini,"timep","5000"));
        vstart=Utils.getIni(ini,"vstart","").replace("@","=");
        vend=Utils.getIni(ini,"vend","").replace("@","=");
        vvstart=Utils.getIni(ini,"vvstart","").replace("@","=");
        vvend=Utils.getIni(ini,"vvend","").replace("@","=");
        wtoken=Utils.getIni(ini,"wtoken","");
        taskname=Utils.getIni(ini,"taskname","");
        pm=Utils.getIni(ini,"pm","");
        dealer=Utils.getIni(ini,"dealer","");
        dealermore=Utils.getIni(ini,"dealermore","");

        output=Utils.dr(Utils.getIni(ini,"output","ser"));
        if(output.equals("ser")){output=ser;}
        if(ps==-1){
            ps=Integer.valueOf(Utils.getIni(ini,"run_now","1"));
            if(ps<=0){ps=1;}
        }
        }catch (Exception e){
            System.out.println("[Pro][Config]配置项读取异常错误,注意配置项的存在和格式问题,配置项:"+iei);
            System.exit(1177);
        }
       //开始爬虫准备
        if (pm.equals("nei")){
            urlp=Utils.urladdp(urlp,"nei","show");

        }


        if(!new File("D:/chromedriver.exe").exists()){
            System.out.println("[Pro]谷歌浏览器驱动文件D:/chromedriver.exe不存在,即将退出...");
            System.exit(88);
        }else{
            Utils.kill("chrome.exe");
            Thread.sleep(1000);
            start();
        }


    }

    //爬虫主程序，开始爬虫
    public static void start() throws IOException, InterruptedException {

        //DealerTest(taskname,"61a13de86d62975f6a364844","Q:/test/deal.txt");
        //--初始化和输出控制台状态：
        List<String> vlist=new ArrayList<>();
        Integer pslog=ps;
        Boolean xunhuan=true;
        int i = 0;
        while (xunhuan) {

            if(danvid.isEmpty()){
                if(pm.equals("url")){
                    if(pn==1){
                        System.out.println("[Pro][Url]Page:"+ps+" ...");
                    }else{
                        System.out.println("[Pro][Url]Page:"+ps+"->"+(pn+pslog-1)+" ...");
                    }
                } else if (pm.equals("nei")) {
                    System.out.println("[Pro][Nei]Nei From "+urlp+"...");
                } else{
                  System.exit(131);
                }
            }else{
                System.out.println("[Pro][Url-Dan]Dan as "+danvid+"...");
            }
        if(ps>pl && pl>0 && pm.equals("url")){
                Utils.sendmsg("[Pro][Pl]当前P"+ps+",到达P"+pl+"，自动退出...","FS-Finish","ts_finish.wav");
                System.exit(99);
            }

        //--计算页码URL
            if(danvid.isEmpty()){
                if(pm.equals("url")){
                    String html=Chrome.open(urlp.replace("[page]",String.valueOf(ps)));

                    Pattern pa=Pattern.compile("(?s)"+vstart+"(.*?)"+vend);
                    Matcher ma=pa.matcher(html);
                    while (ma.find()){

                        vlist.add(Chrome.reg(ma.group(0),"(?<="+vvstart+")(.*)(?="+vvend+")"));
                    }

                } else if (pm.equals("nei")) {
                    String neiadd=Utils.httpget(urlp);
                    if(!neiadd.isEmpty() && !neiadd.toLowerCase().contains("noone")){
                        vlist.add(neiadd);
                    }

                } else{
                    System.exit(131);
                }

            }else{
                vlist.add(danvid);
            }
            Utils.putIni(ini,"run_vnumInOnePage",String.valueOf(vlist.size()));

            System.out.println("从列表中读取到的新闻所有ID：");
            System.out.println(vlist);
         //开始读取条目资源（文章资源）
            int jc=0;
            for(String vid:vlist){
                jc++;
                String vidurl=urlv.replace("[vid]",vid);

                String vidmd5=DigestUtils.md5Hex(vid);
                String dirname=vid.length()+ vidmd5.substring(vidmd5.length()-14);
                String nowqz="[Pro]["+Utils.getpmName()+"]["+jc+"/"+vlist.size()+"]"+vid+"->";
                System.out.print(nowqz+"准备开始... \r");
                //开始读取条目资源（文章资源):判断是否重复

                if(checkalsy(vid)){
                    continue;
                }
                //开始读取条目资源（文章资源):具体抓取，可能有异常所以try包围
                try{
                    //获取资源条目信息
                    //List<String> vimage=new ArrayList<>();
                    System.out.print(nowqz+"正在分析... \r");

                    String vhtml="";
                    while (vhtml.isEmpty()){
                        vhtml=Chrome.open(vidurl);
                        if(vhtml.contains("<title>502")){
                            vhtml="";
                        }
                        if(vhtml.contains("找不到网页")){
                            throw new Exception("[JUMP]404视频页面不存在");

                        }
                        Thread.sleep(3000);
                    }

                    vhtml="[TOP][TASKNAME="+taskname+"][VID="+vid+"][DIR="+dirname+"]请使用脚本程序进行本文件的处理，提取成json字符串即可。"+System.lineSeparator()+vhtml;
                    FileUtil.writeString(vhtml,cache+"/deal.txt","utf-8");
                    if(new File(dealer).isFile() && !dealer.isEmpty()){
                        Runtime.getRuntime().exec("cmd /c "+dealer+" "+cache+"/deal.txt");
                    }else{
                       Dear.Dealer(cache+"/deal.txt");
                    }

                    boolean inc=true;
                    while (inc){
                        vhtml = FileUtil.readUtf8String(cache + "/deal.txt");
                        inc=vhtml.contains("[TOP]");
                        Thread.sleep(2000);
                    }
                    if(vhtml.contains("[JUMP]")){
                        throw new Exception("[JUMP]ShortVideo or VidIsNull");
                    }
                    File dirnamef=new File(cache+"/"+dirname);
                    if(!dirnamef.exists()){
                        dirnamef.mkdir();
                    }
                    FileUtil.writeString(vhtml,cache+"/"+dirname+"/json.meta","utf-8");
                    String vjson=Utils.vjd(vhtml,cache+"/"+dirname,nowqz+"DN"+dirname+":[sz][sd]下载附件资源中...");

                    //下载后处理器
                    if(new File(dealermore).isFile() && !dealermore.isEmpty()){
                        Runtime.getRuntime().exec("cmd /c "+dealermore+" "+vid+"##"+dirname);
                    }else{
                        Dear.Dealermore(vid,cache+"/"+dirname,nowqz);
                    }

                    //上传（条目信息上传,资源需手动FTP上传）
                    System.out.print(nowqz+"正在发布... \r");
                    if(new File(output).isDirectory()){
                        FileUtil.writeString(vjson,output+"/"+vid+".txt","utf-8");
                    }else{

                        String postres=Utils.httppost(Utils.urladdp(output,"dirname",dirname),vjson);
                        //System.out.println("postres="+postres);

                        if(!checkalsy(vid)){
                            URLCodec urlCodec = new URLCodec();
                            Utils.putIni(ini,"run_postres",urlCodec.encode(postres));
                            throw new Exception("[END]发布失败，具体原因请参见run_postres");
                        }
                    }
                    System.out.print(nowqz+"本条已完成. \r");

                }catch (Exception e){
                    //try：异常进行回滚事务。
                    System.gc();
                    callbacksy(vid);
                    e.printStackTrace();

                    Utils.sendmsg("[Pro]["+vid+"][Error]过程出错,进行回滚...","",((e.toString().contains("[JUMP]"))?"":"ts_error.wav"));


                    Thread.sleep(3000);
                    if(e.toString().contains("[END]")){
                        System.exit(88);
                    }
                }
                Thread.sleep(timev);
            }
        //测试(For:Nei)
            /*if(true){
                break;
            }*/
        //该页面抓取结束
            if(!danvid.isEmpty() | vlist.size()==0){xunhuan=false;break;}
            Utils.sendmsg("","","ts_mid.wav");
            vlist.clear();
            ps++;
            Utils.putIni(ini,"run_now",String.valueOf(ps));
            Thread.sleep(timep);

        //进入下一个页面
            i++;
            xunhuan=(i < pn);

        }


        //全部页面结束
        Utils.sendmsg("[Pro]全部完成以结束","FS-Finish","ts_finish.wav");
        System.exit(99);

    }


    //方法函数：回滚撤销（产生爬抓过程错误时对事务的回滚）
    public static void callbacksy(String vid)  {
        HttpUtil.get(Main.ser+"?callback="+vid);
    }

    //方法函数：检查存在（对重复条目的跳过爬取）
    public static boolean checkalsy(String vid)  {
        if(!Main.ser.startsWith("http") || Main.ser.equals("N")){
            return false;
        }
        String http=Utils.httpget(Main.ser+"?checkal="+vid);
        return http.endsWith("al");

    }
}