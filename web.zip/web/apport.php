<?php
//装载:所有文件可以放置在新的站点的spider中。需要PHP支持PDO。a_开头的文件为插件支持。每个文件的数据库信息是独立的。
//sdom=""，不使用网站地图，sdom需要等于带https头，不/结尾的首页，如https://baidu.com，使用该功能需先进行addsm=id进行测试。
//creat是创建表的mysql语句。填写sg禁止不存在提示。不会自动创建。//NEI—SQL列：id,vid,tim
//手工编写:callback函数中对于wp的文章回滚DELETE,本PHP程序默认为资源表和WP表同属同个服务器和数据库,如非请自行修改。
//资源表：注意当wpsend=true时启动wordpress文章发布,dealer处理器需要至少提供$title,$nr,$catename三个字段（$vid是必须的）。
//资源表：sql还需要在尾部按顺序预留nums,word_tags,dirname,tim_creat 四个拓展字段。
//资源表：dealer处理json时返回的字段需要与数据库的相匹配

//配置项（需手动修改）
    $db['ip']="localhost";
    $db['dbname']="rfjfttey_swabc";
    $db['username']="rfjfttey_sub";
    $db['password']="xxxxxxxxx";
    $creat="sg";
    $wpsend=true;
    $wpusername="root";
    $wppassword="i7GU 7q0K gWKc xiUF YXLK SJb5";
    $sdom="https://minknown.com";
    $table="sp_swxxx";
    $neimaxcount=2000;//nei
    $table_nei="sp_nei";
   
//初始化

    header("Content-type: text/html; charset=utf-8"); 
    session_start();
    error_reporting(1);
    date_default_timezone_set('PRC');
    $taskname=$_GET['taskname'];
    $dn=time();
    if($creat==""){die("请先设置creat语句,在apport.php中。");}
    if($_POST['postinfo']!="" and $wpsend==true){
        $wpload=dirname(__FILE__) . '/../wp-load.php';
        if(!file_exists($wpload)){die("wpload文件不存在:".$wpload);}else{
        require($wpload);
        }
        $headers = array (
        'Authorization' => 'Basic ' . base64_encode( $wpusername . ':' .$wppassword ),
        );   
    }
    
    $nei=$_GET['nei'];//nei
    if($nei==""){$nei=$_POST['nei'];}
//图片接口
if($_GET['image']!=""){
    header('content-type:image/jpg;');
    $f=explode("__",$_GET['image']);//vid+dirname
    $local="../vids/".$f[1]."/0.jpg";
    if(file_exists($local)){
      echo file_get_contents($local);
    }else{
       echo file_get_contents("https://public.xxxx.xxx/z/".$f[0]."/poster.jpg?size=1024x1024&format=jpg&preset=sd");
    }
    
    exit();

}
//微信通知，解决部分电脑无法使用通知问题
if($_GET['tz']!=""){
    echo file_get_contents("http://pushplus.plus/send?token=".$_GET['wtoken']."&title=SPIDER&content=".$_GET['tz']);
    exit();
}
//连接数据库
try{$con = new PDO("mysql:host=". $db['ip'].";dbname=".$db['dbname'],$db['username'],$db['password']);$con->query("SET NAMES UTF8");}catch(PDOException $e) {
    echo "SQL库连接失败,可能是PDO不支持或SQL信息不对:" . $e->getMessage();exit();
}
	
	
	
//接口_简单显示某个资源
//(通常这里是WP文章进入资源的入口,并不作为独立资源站的资源页)(可以在此处增加标签化装载)
if($_GET['enter']!=""){
     $qq="SELECT * FROM ".$table." WHERE vid='".$_GET['enter']."' or id='".$_GET['enter']."' limit 1";
     $res=$con->query($qq)->fetch();
     echo "<p><a style='color:green' href='https://xxxxx.com?qd=bc'>点此进入完整版</a><p>";
     echo "<pre>";
     var_dump($res);
     echo "</pre>";
     $con=null;exit();
}

//接口_回滚删除(提供vid,回滚如有必要可删除相关资源目录,通过deldir函数,如deldir("video/".$_GET['callback']))
if($_GET['callback']!=""){
      $qq="DELETE FROM ".$table." where vid='".$_GET['callback']."'";
      $con->query($qq);
      $qq="DELETE FROM wp_posts where post_type='post' and post_name='".$_GET['callback']."'";//默认认为同库
      $con->query($qq);
      $con=null;die("OK");
}

//接口_检查服务器是否存在某资源，给客户端跳过扫描提供参考意见
if($_GET['checkal']!=""){
    $qq="SELECT * FROM ".$table." WHERE vid='".$_GET['checkal']."' limit 1";
    $res=$con->query($qq)->fetch();
    if($res['id']>0){echo "al";}else{echo "sorry";}
    $con=null;exit();
}
 
//接口(NEI)_获得一个任务并删除该任务。
if($nei!="" and $nei=="show"){
         $qq="SELECT * FROM ".$table_nei." where sta=1 order by RAND() limit 1";
         $v=$con->query($qq)->fetch();
         if($v['id']<=0){
             echo "Noone";
         }else{
             echo $v['vid'];
             $qq="UPDATE ".$table_nei." set sta=0 WHERE id='".$v['id']."' limit 1";
             $con->query($qq);
         }
        $con=null;exit();
    }


//接口(NEI)_增加新任务
 if($nei!="" and $nei!="show"){
         $qq="SELECT count(*) as nums FROM ".$table_nei."";
         $n=$con->query($qq)->fetch();
         $neis=explode("__",$nei);
         if($n['nums']>=$neimaxcount){unset($neis);}
         foreach($neis as $avid){
             $qq="SELECT * FROM ".$table_nei." WHERE vid='".$avid."' limit 1";
             $v=$con->query($qq)->fetch();
             if($v['id']<=0){
                 $qq="INSERT INTO ".$table_nei." (id,vid,sta,tim) values (NULL,'".$avid."',1,'".$dn."')";
                 $con->query($qq);
             }
         }
         $con=null;die("ADD-FINISH");
}
    
 
//接口:发布资源(和WP)
if($_POST['postinfo']!=""){
    
    $sql = "show tables like '".$table."'";
    $result=$con->query($sql)->fetchAll();

    if(count($result)<=0){
        $sql=$creat;
        $con->query($sql);
        if($creat=="sg"){die("请手工建立表,表不存在");}
    }
    
    //json解析
    //echo "<--------->服务器收到的post参数postinfo为".$_POST['postinfo']."<----------------->";
   
   
    $content=stripslashes($_POST['postinfo']);
    $content =str_replace("\\","",$content);
    $vinfo=json_decode($content,true);
    $vinfo['nr']=str_replace("*",'"',$vinfo['nr']);
      $before="id";
      $after="NULL";
      foreach ($vinfo as $key => $value) {
          if($key!="id" and substr($key,0,3)!="ig_"){
          $before=$before.",".$key;
          $after=$after.",'".$value."'";
          }
      }
      
    //mysql新增
    $qq="SELECT * FROM ".$table." WHERE vid='".$vinfo['vid']."' limit 1";
    $temp=$con->query($qq)->fetch();
    if($temp['id']<=0){
        $qq="INSERT INTO ".$table." (".$before.",nums,word_tags,dirname,tim_creat) values (".$after.",0,'','".$_GET['dirname']."','".$dn."')";
        $con->query($qq);//执行
        $re['sql']=$qq;$add=1;$inid=$con->lastInsertId();$re['inid']=$inid;
    }else{
         $re['sql']="no-to-mysql(al)";
         $re['inid']=-1;
    }
    if($temp['id']<=0 and $inid>0 and $add==1){
          addsm($inid);
     }
 
    //wp新增
    $re['wpsend']=$wpsend;
    if($wpsend==true and $inid>0){
       $re['wp']=sendtowp($vinfo['title'],$vinfo['nr'],$vinfo['vid'],$vinfo['catename']); 
    }else{
      $re['wp']="no-to-wp";
    }
    echo json_encode($re);
    $con=null;exit();
    
    
}

//支持方法

//删除非空目录 
function deldir($dir){
    if(file_exists($dir)){
          $files=scandir($dir);
          foreach($files as $file){
                 if($file!='.' && $file!='..'){
                         $path=$dir.'/'.$file;
                         if(is_dir($path)){
                                 deldir($path);
                          }else{
                                  unlink($path);
                          }
                  }
           }
           rmdir($dir);
           return true;
    }else{
           return false;
    }
}

//wp:发布文章[需传入catename,title,nr]
function sendtowp($title,$nr,$slug,$catename){
    global $headers;
    $nr=str_replace("FGF","'",$nr);
    //带RF不做JAVA客户端提示。
    if(getpostid($slug)>0){die("[NT][RR]发布失败,别名SLUG已经重复");}
 
    $cateid=getcateid(catetran($catename));

    if($cateid==""){
        $cateid=putcate($catename);
    }
    if($cateid<=0){die("发布失败,分类生成或获取失败");}
    $urlwant="posts";
    $data = array(
    'status'=>'publish',
    'title' => $title,
    'content' => $nr,
    'categories'=>$cateid,//tags
    'slug'=>$slug
    );
    
    //send
    $url = rest_url( 'wp/v2/'.$urlwant.'/' );
    $response = wp_remote_post( $url, array (
        'method'  => 'POST',
        'headers' => $headers,
        'body'    =>  $data
    ) );
    $res=json_decode($response['body'],true);
    if($res['data']['status']==""){
        return "OK";
    }else{
        return $response['body'];
    }
};

//wp依赖方法

//[分类]分类名转化为唯一标识符
function catetran($cname){
    
    $all="";
    if (extension_loaded('mbstring')) {
        $len = mb_strlen($cname, 'utf-8'); // 获取字符串长度，需使用utf-8编码
        for ($i = 0; $i < $len; $i++) {
            $char = mb_substr($cname, $i, 1, 'utf-8'); // 获取单个字符
            $all=$all.ord($char);
        }
        //缩短算法
        $th=array("11"=>"9","22"=>"8","33"=>"7","44"=>"6","1"=>"a","2"=>"b","3"=>"c","4"=>"d","5"=>"e","6"=>"f","7"=>"g","8"=>"h","9"=>"j","0"=>"z");
        foreach($th as $key=>$value){
            $all=str_replace($key,$value,$all);
        }
        //增加唯一性
        $all=$all.substr(md5($cname),-4).strlen($cname);
        
    }else{
        $all="C".md5($cname);
    }

    return $all;
}
//[分类]别名获取分类ID，当分类不存在返回空。
function getcateid($theslug){
    global $headers;
    $url = rest_url( 'wp/v2/categories/' );
    $theresponse = wp_remote_post( $url, array (
    'method'  => 'GET',
    'headers' => $headers,
     'body'=>array('slug'=>$theslug)
    ) );
    $theres=json_decode($theresponse['body'],true);
    return $theres[0]['id'];
}

//[分类]创建分类(重复会创建)
function putcate($thename){
    global $headers;
    $url = rest_url( 'wp/v2/categories/' );
    $theresponse = wp_remote_post( $url, array (
    'method'  => 'POST',
    'headers' => $headers,
    'body' => array(
        'name' => $thename,
        'description' =>$thename,
        'slug'=> catetran($thename),
        'parent'=>'0'
    )));
    $res=json_decode($theresponse['body'],true);
    return $res['id'];
}


//[标签]别名获取标签ID，不存在返回空。
function gettagid($theslug){
    global $headers;
    $url = rest_url( 'wp/v2/tags/' );
    $theresponse = wp_remote_post( $url, array (
    'method'  => 'GET',
    'headers' => $headers,
    'body'=>array('slug'=>$theslug)
    ) );
    $theres=json_decode($theresponse['body'],true);
    return $theres[0]['id'];
 
}

//[标签]创建标签(重复会创建)
function puttag($thename){
    global $headers;
    $url = rest_url( 'wp/v2/tags/' );
    $theresponse = wp_remote_post( $url, array (
    'method'  => 'POST',
    'headers' => $headers,
    'body' => array(
        'name' => $thename,
        'description' =>$thename,
        'slug'=> "T".md5($thename)
    )));
    $res=json_decode($theresponse['body'],true);
    return $res['id'];
}

//[标签]别名获取文章ID，不存在返回空。
function getpostid($theslug){
    global $headers;
    $url = rest_url( 'wp/v2/posts/' );
    $theresponse = wp_remote_post( $url, array (
    'method'  => 'GET',
    'headers' => $headers,
    'body'=>array('slug'=>$theslug)
    ) );
    $theres=json_decode($theresponse['body'],true);
    return $theres[0]['id'];
 
}

//网站地图方法(post)
if($_GET['addsm']!=""){addsm($_GET['addsm']);die("SiteMap-AddTest-Finish.");}
function addsm($theid){
   
      global $sdom;
      if($sdom==""){return;}
      if(!is_dir("sitemaps")){mkdir("sitemaps");}
      while($smfile==""){
       $smjc++;
	       $nr=file_get_contents("sitemaps/".$smjc.".xml");
	        $nrls=explode(PHP_EOL,$nr);
	        if(count($nrls)<4900){
	            $smfile="sitemaps/".$smjc.".xml";
	        }
	}
    $nr=file_get_contents($smfile);
    $nr=str_replace("</urlset>","",$nr);
        if($nr==""){
            $nr='<?xml version="1.0" encoding="utf-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'.PHP_EOL.'<url><loc>'.$sdom.'</loc></url>'.PHP_EOL;
            $oldr=file_get_contents("../robots.txt");
            if(strpos($oldr,$smfile)<=0){
            file_put_contents("../robots.txt", $oldr.PHP_EOL."Sitemap:".$sdom."/".basename(__DIR__)."/".$smfile);
            }
        }
            $nr=$nr."<url><loc>".$sdom."/article_".$theid.".html</loc></url>".PHP_EOL."</urlset>";
        $smfiles=scandir("./sitemaps");
        foreach($smfiles as $smline){
           if($smline!="." and $smline!=".."){
               if(strpos(file_get_contents("sitemaps/".$smline),"_".$theid.".html")>0){
                   $nr="";
                   break;
               }
           }
      }
      if($nr!=""){file_put_contents($smfile,$nr);}
  
}
//-----------------------------------------------------

    


echo "HELLO,SPIDER!";
