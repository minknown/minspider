package com.mayizt;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 用户：Administrator
 * 描述：处理器
 */
public class Dear {

    public static void DealermoreTest(String thevid,String thedirname) {
        Dealermore(thevid,thedirname,"DealermoreTest...");
    }
    public static void Dealermore(String thevid,String thedirname,String textinfo)  {
        System.out.print(textinfo+"正在处理下载后的资源... \r");
        //这里可以对0.mp4进行水印处理，以及1.mp4处理。
        try{
            if(true){return;}
            Thread.sleep(5000);
            System.out.println("del"+thedirname+"/0.jpg");
            Thread.sleep(5000);
            FileUtil.del(thedirname+"/0.jpg");
        }catch(Exception e){}

    }
    //方法函数：内置处理器（在dealer为空时生效,用于从文章详细页面中处理信息的中间件）
    public static void DealerTest(String taskname,String vid,String fname) {
        Utils.kill("chrome.exe");
        if(!vid.equals("def")){
            String vhtml=Chrome.open("https://aiqiyi.live/post/"+vid);
            vhtml="[TOP][TASKNAME="+taskname+"][VID="+vid+"][DIR=DealerTest]请使用脚本程序进行本文件的处理，提取成json字符串即可。"+System.lineSeparator()+vhtml;
            FileUtil.writeString(vhtml,fname,"utf-8");
        }
        Dealer(fname);
        System.out.println("[Pro]测试Dearler完成。结果在"+fname);
        System.exit(112233);
    }

    public static void Dealer(String fname) {

        //初始化
        Map<String,String> wre=new HashMap<>();
        String json;
        String txt=FileUtil.readUtf8String(fname);
        String nr= StrUtil.subBetween(txt,"icontent","editor");
        wre.put("nr",nr);

        String title= StrUtil.subBetween(txt,"<title>","</title>");

        wre.put("title",title);

        json= JSONUtil.toJsonStr(wre);
        json=json+System.lineSeparator()+"------"+System.lineSeparator();
        json=json+"http://upload.mnw.cn/2019/1014/thumb_145_95_1571017040195.jpg"+System.lineSeparator();
            //注意这里的顺序，决定了DealerMore的处理文件名，按资源序号编排。
            /*json=json+System.lineSeparator()+"------"+System.lineSeparator();
            json=json+pt+"/"+vid+"/"+ucode+"/trailer.mp4"+System.lineSeparator();//0.mp4
            json=json+pt+"/"+vid+"/"+ucode+"/trailer.mp4?preset=sd"+System.lineSeparator();//1.mp4
            json=json+pt+"/"+vid+"/poster.jpg?size=1024x1024&format=jpg&preset=sd";//0.jpg*/
        ArrayList<String> vids=new ArrayList<>();
        String neiaddurl=Main.urlp.replace("show",String.join("__",vids));
        if(Main.neiadd){
            Utils.httpget(neiaddurl);
            wre.put("ig_neiaddurl","yincang");//neiaddurl
        }
        FileUtil.writeString(json,fname,"utf-8");

    }
}
