package com.mayizt;

/**
 * 用户：Administrator
 * 描述：播放音乐
 */
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.UnsupportedAudioFileException;

public class Playwav {

    public static AudioInputStream audioStream;
    public static AudioFormat audioFormat;
    public static SourceDataLine sourceDataLine;


    //播放音乐，一次性，如果报错请检查电脑是否开启扬声器或耳机，以及驱动。
    public static void play(String path){
        if(path.startsWith("ts_")){
            path=Main.class.getClassLoader().getResource(path).getPath();
        }
        try{
            int count;
            byte buf[] = new byte[1024];

            //获取音频输入流
            audioStream = AudioSystem.getAudioInputStream(new File(path));
            //获取音频的编码格式
            audioFormat = audioStream.getFormat();

            DataLine.Info dataLineInfo = new DataLine.Info(SourceDataLine.class,
                    audioFormat,AudioSystem.NOT_SPECIFIED);

            sourceDataLine = (SourceDataLine)AudioSystem.getLine(dataLineInfo);

            sourceDataLine.open(audioFormat);
            sourceDataLine.start();
            //播放音频
            while((count = audioStream.read(buf,0,buf.length)) != -1){
                sourceDataLine.write(buf,0,count);
            }
            //播放结束，释放资源
            sourceDataLine.drain();
            sourceDataLine.close();
            audioStream.close();
        }catch(UnsupportedAudioFileException ex){
            ex.printStackTrace();
        }catch(LineUnavailableException ex){
            ex.printStackTrace();
        }catch(IOException ex){
            ex.printStackTrace();
        }
    }


}
