<?php
//参数和测试
$appcode = "e5aae1d665dc4343bfad789f73f545d4ddd";
//给外部使用的writemore接口
if($_GET['writemore']!=""){
    $db['ip']="localhost";ss
    $db['dbname']="rfjfttey_sub";
    $db['username']="rfjfttey_sub";
    $db['password']="www07548xsssss!";
    try{$cony = new PDO("mysql:host=". $db['ip'].";dbname=".$db['dbname'],$db['username'],$db['password']);$cony->query("SET NAMES UTF8");}catch(PDOException $e) {
    echo "SQL库连接失败,可能是PDO不支持或SQL信息不对:" . $e->getMessage();exit();
    }
	
    //$title=urldecode($_GET['writemore']);
    echo gettags($cony,"niceo_taolu",42);
    $cony=null;ssssssss
    exit();
}

	

//获得标签化
function gettags($con,$tablename,$id){
    //从资源表通过$id得到记录、标题
    $qq="select id,title,word_tags from ".$tablename." where id=".$id;
    $res=$con->query($qq)->fetch();
    //从标题掉哟个API获得词汇
    if($res['title']!=""){
        
        if($res['word_tags']!=""){
            $wordstext=$res['word_tags'];
        }else{
            $words=cw($res['title']);
            if(count($words)>0){
                $wordstext=implode("#",$words);
            }else{
                $wordstext="null";
            }
            
            if($wordstext!=""){
            $qq="update ".$tablename." set word_tags='".$wordstext."' where id=".$res['id'];
            $con->query($qq);
            }
        }
    }
   return $wordstext;
}



//获得扩写标题
function writemore($con,$tablename,$title){
    
    //从标题获得分词，并枚举查库
    $words=cw($title);
    if(count($words)<=0){return "";}
    foreach($words as $word){
        //echo $word."|";
          $qq="select id,title from ".$tablename." where title LIKE '%".$word."%' and title!='".$title."'";
          $res=$con->query($qq); 
          while($row = $res->fetch()) {
             $theres[$row['id']]=$row;
          }
          
    }
    
    //枚举计算重合度,整理和排序
    foreach($theres as $key=>$value){
        $jc=0;
        foreach($words as $word){
           
            if(strpos("A".$value['title'],$word)>0){

              $jc++;  
            }
        }
        $theres[$key]['jc']=$jc;
        
    }
    $res=array_values($theres);
    $res=sigcol_arrsort($res,"jc");
    

    //返回
 
    for($j=0;$j<min(5,count($res))-1;$j++){
    $ress=$ress.($ress==""?"":",").$res[$j]['title'];
    }
    $nu=array("1","2","3","4","5","6","7","8","9","0","分","钟","【","】","[","]");
    $j=0;
    foreach($nu as $nuu){
        $ress=str_replace($nu[$j],"",$ress);
        $j++;
    }
    return $ress;
}

//函数：调用分词API
function cw($juzi){


   
    global $appcode;
    $host = "http://wbfxfc.market.alicloudapi.com";
    $path = "/rest/160601/text_analysis/aliws.json";
    $method = "POST";
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    //根据API的要求，定义相对应的Content-Type
    array_push($headers, "Content-Type".":"."application/json; charset=UTF-8");
    $querys = "";
    $bodys = "{\"inputs\":[{\"text\":{\"dataType\":50,\"dataValue\":\"".$juzi."\"}}]}";
    $url = $host . $path;

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);
    //遇到错误时请将此设置为true，但是设置为true时json_decode将失效。原因是$retext包含HTTP头信息
    if (1 == strpos("$".$host, "https://"))
    {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    }
    curl_setopt($curl, CURLOPT_POSTFIELDS, $bodys);
    $retext=curl_exec($curl);
    $theres=json_decode($retext,true);
    $tres=$theres['outputs'][0]['outputValue']['dataValue'];
    $thedd=json_decode($tres,true)['tokens'];
    if(count($thedd)==0){return null;}
    foreach($thedd as $temp){
         if(strlen($temp['word'])>=6 and strlen($temp['word'])<=12 and strstr($temp['word'],"分")==false){
          $dd[]=$temp['word'];
        }
    }
    return array_unique($dd);

}

//函数：排序
function sigcol_arrsort($data,$col,$type=SORT_DESC){
    if(is_array($data)){
		$i=0;
	    foreach($data as $k=>$v){
			if(key_exists($col,$v)){
		        $arr[$i] = $v[$col];
				$i++;
			}else{
			    continue;
			}
		}
	}else{
	    return false;
	}
	array_multisort($arr,$type,$data);
	return $data;
}