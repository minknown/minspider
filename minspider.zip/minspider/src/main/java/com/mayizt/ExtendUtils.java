package com.mayizt;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.CompressionLevel;
import net.lingala.zip4j.model.enums.EncryptionMethod;
import org.apache.commons.io.FileUtils;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * 用户：Administrator
 * 描述：拓展方法
 */
public class ExtendUtils {

    //一个压缩目录的方法（需传入压缩密码，采用zip技术，zipname为产生的压缩文件包）
    // （jdtextinfo用于控制台的提示，实例值:正在解压中...）
    public static void tozip(String Folder,String zipname,String password,String jdtextinfo) throws IOException {
        System.out.print(jdtextinfo+" \r");
        //获取待压缩的文件列表
        File dir = new File(Folder);
        File[] childf = dir.listFiles();
        List<File> list=new ArrayList<>();
        for(File temp:childf){
           list.add(new File(temp.getPath()));
        }

        File zcf = new File(zipname);if(zcf.exists()){
            FileUtils.forceDelete(zcf);}
        if(!dir.isDirectory()){dir.mkdir();}
        ZipParameters zipParameters = new ZipParameters();
        zipParameters.setEncryptFiles(true);
        zipParameters.setCompressionLevel(CompressionLevel.HIGHER);
        zipParameters.setEncryptionMethod(EncryptionMethod.ZIP_STANDARD);
        //AES加密更强但是服务器unzip可能解压不出来
        ZipFile zipFile = new ZipFile(zipname,password.toCharArray());
        zipFile.addFiles(list,zipParameters);
        zipFile.close();
    }

    //一个支持进度和下载速度显示的下载文件方法(最好在JDK8以上运行)
    // （jdtextinfo用于控制台的提示,支持[sd]显示速度和[sz]显示文件大小,示例值：[sd]正在下载该文件...）
    public static void downloadf(String urlString, String filename,String jdtextinfo) throws Exception {

        System.out.print(jdtextinfo.replace("[sd]","").replace("[sz]","")+" \r");
        if(new File(filename).exists()){
            FileUtils.forceDelete(new File(filename));
        }

        URL url = new URL(urlString);
        URLConnection urlConnection = url.openConnection();
        urlConnection.setRequestProperty("User-agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36");
        urlConnection.setRequestProperty("referer",urlString);
        urlConnection.setRequestProperty("accept","*/*");
        int allsize = urlConnection.getContentLength();
        long tim_s=System.currentTimeMillis();
        double sd=0.0;
        DecimalFormat sddf = new DecimalFormat("#");
        //获取流
        InputStream in = new BufferedInputStream(url.openStream());
        FileOutputStream fileOutputStream = new FileOutputStream(filename);
        //写出
        BufferedInputStream ccc = new BufferedInputStream(in);
        BufferedOutputStream ddd = new BufferedOutputStream(fileOutputStream);
        byte[] temp=new byte[1024];
        int len=0;int al=0;
        double jd=0;

        while ((len=ccc.read(temp))!=-1){
            ddd.write(temp,0,len);
            al=al+len;
            if(al==0){al=1;}//修复 by zero错误。避免al/1024=0
            if(allsize>0){
                jd=(double)al/(double)allsize;
                //修复 by zero错误,+1.0除了避免整/整外,还能避免相同时间戳相减
                sd=(al/1024)/((System.currentTimeMillis()-tim_s+1.0)/1000);


            }else{
                jd=-1;
            }
            String newi=jdtextinfo.replace("[sd]","["+sddf.format(sd).toString()+"kb/s]").replace("[sz]","["+sddf.format(allsize/1024/1024).toString()+"MB]");
            DecimalFormat df = new DecimalFormat("#.00");
            String jdtext=((jd*100<1)?"0.05":df.format((jd*100)));
            System.out.print(newi+",jd="+jdtext+"%...\r");
        }

        ddd.flush();
        ccc.close();
        ddd.close();
        Thread.sleep(3000);//避免获取不到视频时长
        return;

    }


}
