package com.mayizt;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpUtil;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * 用户：Administrator
 * 描述：工具类
 */
public class Utils {
    //从json字符串中下载图片，并返回有效json
    public static String vjd(String vjson,String downdir,String jdtextinfo){
        if(!vjson.contains("---")){
            return vjson;
        }else{
            String revjson="";
            String[] lines=vjson.split(System.lineSeparator());
            int jc_image=0;
            int jc_video=0;
            int all=vjson.split("http").length;
            for(String line:lines){
                if(line.startsWith("http")){
                    String j="jc="+(jc_image+jc_video+1)+"/"+(all-1);
                    try {

                        if(line.trim().contains(".mp4")){
                            ExtendUtils.downloadf(line.trim(),downdir+"/"+jc_video+".mp4",jdtextinfo+"mp4,"+j);
                            jc_video++;
                        }else{
                            ExtendUtils.downloadf(line.trim(),downdir+"/"+jc_image+".jpg",jdtextinfo+"jpg,"+j);
                            jc_image++;
                        }


                    } catch (Exception e) {
                        System.out.println("附件资源下载可能异常。。。");
                    }



                }else{
                    if(line.contains("\"")){
                        revjson=line;
                    }

                }
            }
            return revjson;

        }
    }

    //处理带斜杠的目录
    public static String dr(String dirname){
     if(dirname.endsWith("/")){
         dirname = dirname.substring(0, dirname.length() - 1);
        }
     if(dirname.endsWith("\\")){
            dirname = dirname.substring(0, dirname.length() - 1);
        }
     return dirname;
    }

    public static void sendmsg(String ctrl,String wechat,String musicname){
        if(!ctrl.isEmpty()){
            System.out.println(ctrl);
        }
        if(!wechat.isEmpty()){
            tz(wechat);
        }
        if(!musicname.isEmpty()){
            Playwav.play(musicname);
        }
    }
    //格式化SG描述
    public static Map dealDesc(String desc) {
        String thedesc=desc.replace("\\n","<br>").replace("<br><br>","<br>").replace("<br>.","").replace(" ","");
        String[] thedescs=thedesc.split("<br>");
        String aline="";
        Map<String,String> res=new HashMap<>();
        for(String temp:thedescs){
            String[] ls= temp.split("#");
            if(ls.length>=3){
                thedesc= thedesc.replace(temp,"");
                aline=temp.trim();
                break;

            }
        }
        thedesc=thedesc.trim();
        if(thedesc.endsWith("<br>")){
            thedesc=(thedesc+"<brr>").replace("<br><brr>","");
        }
        res.put("desc",thedesc);
        res.put("tag",aline);
        return res;
    }

    //格式化SG时间
    public static String dealTim(String tim) {
        String timre="0";
        try{
            tim="T"+StrUtil.subBetween(tim,"DT","S")+"S";
            Integer h=Integer.valueOf(StrUtil.subBetween(tim,"T","H"));
            Integer m=Integer.valueOf(StrUtil.subBetween(tim,"H","M"));
            Integer s=Integer.valueOf(StrUtil.subBetween(tim,"M","S"));
            timre=String.valueOf(h*3600+m*60+s);
        }catch (Exception e){}
        return timre;

    }
    public static String getIni(String furl,String key,String defultvalue) {
        Main.iei=key;
        if(!new File(furl).exists()){return "";}
        String[] temps;
        String[] lines;
        try{
            lines= FileUtils.readFileToString(new File(furl)).split(System.lineSeparator());
        }catch (Exception e){
            lines=null;
        }
        for(String temp:lines){
            temps=temp.split("=");
            if(temps.length==2 && temps[0].equals(key)){
                if(temps[1].toLowerCase().equals("n")){temps[1]="";}
                return temps[1].replace("#","=");
            }
        }
        return defultvalue;

    }
    public static void putIni(String furl,String key,String word) throws IOException {
        word=word.replace("=","#");
        if(word.isEmpty()){
            //移除该设置行
            if(!new File(furl).exists()){
                return;
            }
            List<String> ls=FileUtil.readLines(furl,"utf-8");
            Iterator<String> iterator = ls.iterator();
            while(iterator.hasNext()){
                String temp=iterator.next();
                if(temp.startsWith(key+"=")){
                    iterator.remove();
                }
            }
            FileUtil.writeString(String.join(System.lineSeparator(),ls),furl,"utf-8");
            return;
        }
        String newtxt;
        String w=getIni(furl,key,"");
        if(w.isEmpty()){
            List<String> ls=new ArrayList<>();
            if(new File(furl).exists()){
                ls= FileUtil.readLines(furl,"utf-8");
            }
            ls.add(key+"="+word);

            newtxt=String.join(System.lineSeparator(),ls);
        }else{
            newtxt=FileUtil.readString(furl,"utf-8").replace(key+"="+w,key+"="+word);
        }
        FileUtil.writeString(newtxt,furl,"utf-8");
    }
    public static String getpmName(){
        String res="";
        if(Main.danvid.isEmpty()){
            if(Main.pm.equals("url")){
                res="Url";
            } else if (Main.pm.equals("nei")) {
                res="Nei";
            }else{
                res="Other";
            }
        }else{
            res="Url-dan";
        }
     return res;
    }


    public static String urladdp(String theurl,String key,String word){
        if(theurl.contains("?")){
            theurl=theurl+"&"+key+"="+word;
        }else{
            theurl=theurl+"?"+key+"="+word;
        }
        return theurl;
    }
    //http-get请求，适用于多数的get请求.具有失败重试机制。
    public static String httpget(String url){
        String res="";
        int jc=0;
        urladdp(url,"taskname",Main.taskname);
        while(res.isEmpty()){
            try{
                res= HttpUtil.get(url);
            }catch (Exception e){
                res="";
                jc++;
                //Tools.printInRed("[httpget]["+jc+"]["+url+"]Connection reset,try agant...")
                if(jc>6){
                    System.out.println("[httpget]["+jc+"]["+url+"您的网络可能存在问题...");//todo
                }
                try{Thread.sleep(3000);}catch (Exception ee){}
            }
        }
        return res;
    }

    //这个post特别定制的，只会向url发送一个post=post-json的请求。
    public static String httppost(String url,String postinfo){

        url=urladdp(url,"taskname",Main.taskname);
        String res="";
        int jc=0;
        while(res.isEmpty()){
            try{
                res= HttpUtil.post(url,"postinfo="+postinfo);
            }catch (Exception e){
                e.printStackTrace();
                res="";
                jc++;
                //Tools.printInRed("[httpget]["+jc+"]["+url+"]Connection reset,try agant...")
                if(jc>6){
                    System.out.println("[httppost]["+jc+"]["+url+"您的网络可能存在问题...");//todo
                }
                try{Thread.sleep(3000);}catch (Exception ee){}
            }
        }
        return res;
    }
    public static void tz(String nr){
        if(!Main.wtoken.isEmpty()){
        String urlt=Main.ser+"?wtoken="+Main.wtoken+"&tz="+nr;
        Utils.httpget(urlt);
        }
    }
    public static void  kill(String killname){
        String cmd="taskkill /f /im "+killname;
        try {
            Runtime.getRuntime().exec(cmd);
        } catch (IOException e) {
            System.out.println("调用cmd错误，来自工具类kill方法。");
        }
    }
}
