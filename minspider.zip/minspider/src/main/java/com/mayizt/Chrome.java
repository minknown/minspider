package com.mayizt;


import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.File;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// 按两次 Shift 打开“随处搜索”对话框并输入 `show whitespaces`，
// 然后按 Enter 键。现在，您可以在代码中看到空格字符。
public class Chrome {
    public static ChromeDriver driver=null;
    public static ChromeDriverService service=null;
    public static boolean lock =false;
    //简单正则使用方法(单条返回)
    public static String reg(String txt,String reg) {
        Pattern pa=Pattern.compile(reg);
        Matcher ma=pa.matcher(txt);
        while (ma.find()){
            return ma.group();
        }
        return "";
    }




    public static void close() {

        try{

           if(driver==null){}else{
                    driver.quit();//close()则当前窗口而已
                    driver=null;
                    service.stop();
                    Thread.sleep(2000);
           }

        }catch (Exception e){
            System.out.println("[Pro]关闭Chromedirver异常(quit),但不影响继续程序继续运行。");
        }

    }

    //浏览器访问
    public static String open(String url){
        //System.out.println(url);
        if(url.contains("index-1.html")){
            url=url.replace("index-1","index");
        }


        //锁
        while(lock){
            try{Thread.sleep(10000);
            }catch (Exception e){}
        }
        lock=true;
        //配置不输出日志
        System.setProperty("webdriver.chrome.silentOutput", "true");
        Logger.getLogger("org.openqa.selenium").setLevel(Level.OFF);

        //如果没有配置环境变量，需要调用
        System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
        String content="";
        boolean xunhun=true;
        int xunhuncs=0;
        while (xunhun){
            try {

                if(driver==null){
                    //Tools.kill("chrome.exe");
                    Thread.sleep(1000);
                    System.out.println("[Pro][Chrome]首次启动Chrome...");
                    service=new ChromeDriverService.Builder().withLogOutput(System.out).build();
                    ChromeOptions options = new ChromeOptions();//options.addArguments("headless");

                    options.addArguments("start-maximized", "no-sandbox", "user-data-dir="+Main.cache+"/userdata");
                    options.addArguments("disable-gpu");

                    //设置不显示图片
                    HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
                    chromePrefs.put("profile.managed_default_content_settings.images", 2);
                    options.setExperimentalOption("prefs", chromePrefs);


                    //-设置下载路径
                    //HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
                    //chromePrefs.put("profile.default_content_settings.popups", 0);
                    //chromePrefs.put("download.default_directory", "D:/");
                    //options.setExperimentalOption("prefs", chromePrefs);

                    //设置代理
                    //Proxy proxy = new Proxy();
                    //proxy.setHttpProxy("107.175.153.215:3128");
                    //options.setCapability("proxy", proxy);

                    //-end
                    driver = new ChromeDriver(service,options);
                }

                //读取网页
                driver.get(url);
                content = driver.getPageSource();
                //登录拦截

                if(content.contains(Main.logintext) &&  !Main.logintext.isEmpty()){
                    System.out.print("[Pro]网站需要登录或VIP权限,请执行处后输入任意字符回车继续。");
                    char charinput=(char)System.in.read();
                    driver.get(url);
                    content = driver.getPageSource();
                }
                xunhun=false;

            } catch (Exception e) {
                content="";
                try{Thread.sleep(10000);}catch (Exception ee){};
                xunhuncs++;
                if(xunhuncs>6){
                    e.printStackTrace();
                    System.out.println("[Pro][Url="+url+"]谷歌框架出错,也有可能是网络故障...");
                    xunhun=false;
                }

            }
        }
        lock=false;
        return (content);

    }

}